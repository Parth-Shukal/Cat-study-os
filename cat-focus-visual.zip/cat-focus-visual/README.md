# CAT Focus — Visual study dashboard

Replace the old repository's `index.html` with this one and commit it. Keep the same GitHub Pages URL.

## Features
- Premium dark purple/cyan dashboard with animated-style focus ring.
- Set a countdown from 1 to 600 minutes, or choose 25 / 45 / 60 / 90-minute presets.
- Timer saves the session automatically at zero. Pause/resume and reset are available.
- Weekly and monthly graphs, live totals, and on-demand weekly report.
- Study history is hidden until the user taps View history.
- JSON backup and merge-import.

## Existing data
Uses the existing `cat-study-os-v1` browser storage key and preserves saved session records. Keep the same browser, device and exact Pages URL. Export a backup from the old version before replacing it. If origin/browser changes, import the backup in the new version. An unfinished old stopwatch is not converted into a countdown session; finish/save it in the old app first if its time matters.

The countdown uses elapsed wall-clock time, so switching apps or refreshing does not stop it. Browser storage is local to this browser/device; export backups regularly.
